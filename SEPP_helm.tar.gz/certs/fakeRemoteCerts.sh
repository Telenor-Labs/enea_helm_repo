#!/bin/bash


PEM="remote-esepp.pem"
CRT="remote-esepp.crt"
PKCS8="remote-esepp-pkcs8.pem"

openssl req \
	-x509 \
	-nodes \
	-newkey rsa:4096 \
	-keyout ${PEM} \
	-out ${CRT} \
	-days 60 \
	-subj "/CN=sepp.5gc.mnc16.mcc242.3gppnetwork.org"

openssl pkcs8 \
	-topk8 \
	-inform PEM \
	-outform PEM \
	-in ${PEM} \
	-out ${PKCS8} \
	-nocrypt
