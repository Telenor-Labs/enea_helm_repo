#!/bin/bash -e

declare -a SERVERNAME
SERVERNAME[0]="sepp1.5gc.mnc012.mcc242.3gppnetwork.org"
SERVERNAME[1]="sepp2.5gc.mnc012.mcc242.3gppnetwork.org"
SERVERNAME[2]="sepp3.5gc.mnc012.mcc242.3gppnetwork.org"

BASEFILENAME="enea-esepp"

KEYFILE="${BASEFILENAME}.key"
CSRFILE="${BASEFILENAME}.csr"
CRTFILE="${BASEFILENAME}.crt"
PEMFILE="${BASEFILENAME}.pem"
CA_CRT="${BASEFILENAME}-ca.crt"
CA_KEY="${BASEFILENAME}-ca.key"
# If need to protect with password, uncomment the filename below
#PRIVATE_KEY_PASSWORD_FILE="${BASEFILENAME}-cert_auth_password"

COUNTRY="NO"
STATE="Norway"
CITY="Oslo"
CORPORATION="Telenor"
GROUP="Test"
SUBJ="/C=${COUNTRY}/ST=${STATE}/L=${CITY}/O=${CORPORATION}/OU=${GROUP}/CN=${SERVERNAME[0]}"
DAYS=3650

SSL_CONF="${BASEFILENAME}-ssl.cfg"


VERSION="$(openssl version)"
if [[ ${VERSION} == "OpenSSL 3."* ]]; then
  VERSION=3
elif [[ ${VERSION} == "OpenSSL 1."* ]]; then
  VERSION=1
fi


DATE=$(date +%s)
make_backup () {
  FILE=$1
  if [[ -f ${FILE} ]]; then
    mv -v ${FILE} ${FILE}_before_${DATE}
  fi
}
for BCK in $(ls -1 ${BASEFILENAME}* 2>/dev/null | grep -v _before_) ; do
  make_backup ${BCK}
done


if [[ ! -z ${PRIVATE_KEY_PASSWORD_FILE} ]]; then
  echo "Creating a random password, saving in ${PRIVATE_KEY_PASSWORD_FILE}"
  CERT_AUTH_PASS=$(openssl rand -base64 32)
  echo $CERT_AUTH_PASS > ${PRIVATE_KEY_PASSWORD_FILE}
  CERT_AUTH_PASS=$(cat ${PRIVATE_KEY_PASSWORD_FILE})
fi


run_for_openssl3 () {
  # Create custom configuration file
  cat <<EOF > ${SSL_CONF}
authorityKeyIdentifier=keyid,issuer
basicConstraints=CA:FALSE
subjectAltName = @alt_names
[alt_names]
$(for I in $(seq 0 $((${#SERVERNAME[@]}-1))) ; do
  echo "DNS.$((I+1)) = ${SERVERNAME[$I]}"
done)
EOF


  # create the certificate authority
  echo "Create certificate authority [${CA_CRT}/${CA_KEY}]"
  if [[ ! -z ${PRIVATE_KEY_PASSWORD_FILE} ]]; then
    PASSWORD="-passout pass:${CERT_AUTH_PASS}"
  else
    PASSWORD="-nodes"
  fi
  openssl \
    req \
    -subj "${SUBJ}" \
    -new \
    -x509 \
    ${PASSWORD} \
    -keyout ${CA_KEY} \
    -out ${CA_CRT} \
    -days ${DAYS}


  # create the CSR (Certitificate Signing Request)
  echo "Create the Certificate Signing Request (CSR) [${CSRFILE}] and client key [${KEYFILE}]"
  openssl \
    req \
    -new \
    -newkey rsa:4096 \
    -keyout ${KEYFILE} \
    -nodes \
    -config ${SSL_CONF} \
    -subj "${SUBJ}" \
    -out ${CSRFILE}


  # sign the certificate with the certificate authority
  echo "Sign the certificate with the certificate autority [${CA_CRT}/${CA_KEY}]"
  if [[ ! -z ${PRIVATE_KEY_PASSWORD_FILE} ]]; then
    PASSWORD="-passin pass:${CERT_AUTH_PASS}"
  else
    PASSWORD=""
  fi
  openssl \
    x509 \
    -req \
    -days ${DAYS} \
    -in ${CSRFILE} \
    -CA ${CA_CRT} \
    -CAkey ${CA_KEY} \
    ${PASSWORD} \
    -CAcreateserial \
    -out ${CRTFILE} \
    -extfile ${SSL_CONF}


  cat <<EOM

############# RESULT #############
EOM
  openssl x509 -in ${CRTFILE} -noout -subject -dates -ext subjectAltName

}



run_for_openssl1 () {
  # Create custom configuration file
  cat <<EOF > ${SSL_CONF}
[req]
req_extensions = v3_req
distinguished_name = req_distinguished_name
promtp = no

[req_distinguished_name]
C = ${COUNTRY}
ST = ${STATE}
L = ${CITY}
O = ${CORPORATION}
OU = ${GROUP}
CN = ${SERVERNAME[0]}

[v3_req]
basicConstraints = CA:FALSE
keyUsage = digitalSignature, keyEncipherment
subjectAltName = @alt_names

[alt_names]
$(for I in $(seq 0 $((${#SERVERNAME[@]}-1))) ; do
  echo "DNS.$((I+1)) = ${SERVERNAME[$I]}"
done)

[SAN]
subjectAltName = $(for I in $(seq 0 $((${#SERVERNAME[@]}-2))) ; do
  echo -n "DNS.$((I+1)):${SERVERNAME[${I}]}, "
done; echo "DNS.$((I+2)):${SERVERNAME[${#SERVERNAME[@]}-1]}")

EOF


  # create the certificate authority
  echo "Create certificate authority [${CA_CRT}/${CA_KEY}]"
  if [[ ! -z ${PRIVATE_KEY_PASSWORD_FILE} ]]; then
    PASSWORD="-passout pass:${CERT_AUTH_PASS}"
  else
    PASSWORD="-nodes"
  fi
  openssl \
    req \
    -subj "${SUBJ}" \
    -new \
    -x509 \
    ${PASSWORD} \
    -keyout ${CA_KEY} \
    -out ${CA_CRT} \
    -days ${DAYS}

  # create the CSR (Certitificate Signing Request)
  echo "Create certificate authority [${CA_CRT}/${CA_KEY}]"
  openssl \
    req \
    -new \
    -newkey rsa:4096 \
    -keyout ${KEYFILE} \
    -nodes \
    -config ${SSL_CONF} \
    -reqexts SAN \
    -subj "${SUBJ}" \
    -out ${CSRFILE}

  # sign the certificate with the certificate authority
  echo "Sign the certificate with the certificate autority [${CA_CRT}/${CA_KEY}]"
  if [[ ! -z ${PRIVATE_KEY_PASSWORD_FILE} ]]; then
    PASSWORD="-passin pass:${CERT_AUTH_PASS}"
  else
    PASSWORD=""
  fi
  openssl \
    x509 \
    -req \
    -days ${DAYS} \
    -in ${CSRFILE} \
    -CA ${CA_CRT} \
    -CAkey ${CA_KEY} \
    ${PASSWORD} \
    -CAcreateserial \
    -out ${CRTFILE} \
    -extfile ${SSL_CONF} \
    -extensions SAN

cat <<EOM

############# RESULT #############
EOM
  openssl x509 -in ${CRTFILE} -noout -subject -dates -ext subjectAltName

}



if (( ${VERSION} == 3 )) ; then
  run_for_openssl3
elif (( ${VERSION} == 1 )) ; then
  run_for_openssl1
fi

ln -s ${CRTFILE} certificate.pem
ln -s ${KEYFILE} key.pkcs8

